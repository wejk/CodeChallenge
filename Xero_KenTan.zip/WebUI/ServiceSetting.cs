﻿using System;

namespace WebUI
{
    public class ServiceSetting
    {
        public Uri BaseUrl { get; set; }
    }
}
