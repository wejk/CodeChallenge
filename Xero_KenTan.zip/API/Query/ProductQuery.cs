﻿namespace KenTan.Api.Query
{
    public class ProductQuery
    {
        /// <summary>
        /// Retrieve amount of Product. when limit is 0, default to 10
        /// </summary>
        public int Limit { get; set; }
    } 
}
